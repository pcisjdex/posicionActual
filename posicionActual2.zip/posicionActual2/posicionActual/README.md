## Descripción

Aplicación móvil Android de ejemplo que utiliza la librería de Google Location para obtener la posición del dispositivo, esto lo hace en un servicio que corre en background


## Demostración

<img src="https://crissalvarezh.github.io/ImagenesRepos/imgs/LocationGoogle/location_google_demo.gif" width="250px"/>
